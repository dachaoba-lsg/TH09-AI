# DS-TH09-AI 3.9.0-test

## 3.9：所有难度主动寻找低毒浓度安全区

本版基于 3.8，在毒场中增加低毒浓度区域的移动偏好，**所有难度均生效，包括 mech**。AI 在当前可见范围和允许的移动候选内，倾向选择毒叠加更少、减速负担更低的安全区域，减少持续陷在高浓度毒场中的情况。

毒导航是软地形偏好。原有短程弹幕安全、圆形视野、高度范围、变向限制和实际保护条件仍须成立，不会为了更低的毒浓度直接选择会撞弹或不允许走的方向，也不会根据圈外毒云提前选路。低毒区不等于无弹区；如果安全路线、移速或可达空间不足，仍可能被叠毒困住或受击，不能保证总能逃出毒场。

3.8 的三项人类化移动规则保持：近场持续拥挤时偏好低速、快慢最短保持与危险打断、在安全候选中偏好较宽缓冲。**这三项仍只作用于非 mech；mech 即使设置 `ai.enabled=true` 也继续旁路它们。3.9 新增的避毒偏好才是所有档位共同启用的部分。**

## 原有配置与放 C 策略

`set-difficulty.cmd` 的菜单、操作、命令行参数和保存方式不变；默认 JSON 与四项玩家能力参数不变，无需增加新配置。没有扩大注意力、视野或变向额度，没有改输入映射、原生传感器、1P key 校验和保护逻辑。公开默认仍为 AI=2P、空 `side_key`。

unlimited/infinite 默认 `plan_interval=1`，其他档位和 custom 默认 6；已有 JSON 的显式值仍优先，菜单继续保留该字段。3.7 保命 C2、灵梦 C1、能量及动作门等放 C 策略源码保持。新的站位可能改变后续连爆收益、可见压力和放 C 时机，不能因此保证整局动作或收益与 3.8 完全相同。

## 日志与验证范围

调试 CSV 保留 3.8 的前 203 列及顺序，末尾追加毒导航诊断，用于观察候选毒负担、导航状态和路线选择。未知或无可行路线不表示已确认安全；新增毒导航诊断记录策略使用的证据，不会反过来扩大策略的感知范围。

验证关注有毒与无毒场景、叠毒与更低浓度目标、所有难度及 mech、视野/高度/变向/保护约束、原短程弹幕安全，以及旧菜单和 C 策略兼容。实际完成的测试、计数与限制以本次交付报告为准；历史版本的测试不代替 3.9 新验证，也不声称已经完成新版实战验收。

目标包为 `DS-TH09-AI-v3.9.0-test.zip`。新增 `poison_navigation.lua` 与其余六个 Lua 模块整包配套使用；公开包和随包源码必须同时包含七个模块。继续使用原构建入口，构建无需有效 1P key，不自动安装或启动游戏。

---

# 3.8 及更早历史说明

以下保留历史版本原文；其中 mech 的旁路描述仅指对应的人类化移动规则，当前新增毒导航的适用范围以本页顶部 3.9 说明为准。历史日志列数与版本号不覆盖当前版本。

# DS-TH09-AI 3.8.0-test

## 3.8：非 mech 档位的移动微调

本版基于 3.7，调整密集弹幕中的快慢速选择和安全路线偏好。以下三项只对**非 mech** 档位生效：

- **近场持续拥挤时偏好低速。** 密度只统计圆形视野内、实际纳入当前避弹评分的近场子弹；未被注意力接纳或圈外的子弹不参与这项判断。持续拥挤才进入低速偏好，低速仍须有可行路线，不会因为子弹多就强制减速。
- **减少快慢速频繁切换。** 快速与低速都有最短保持时间，退出低速偏好需要压力持续减轻；当前模式出现即时几何危险时，可以打断保持，选择更安全的模式。保持和滞回不代替真实碰撞判断。
- **安全候选中偏好较宽缓冲。** 在真正可选且安全的路线间，倾向选择离已识别威胁更有余量的方向；安全性、场地及现有移动限制仍优先。不会把较宽但会撞击的路线当成安全路线，也不读取未跟踪对象的精确轨迹来选路。

**mech 完全跳过以上三项新增逻辑，包括手动设置 `ai.enabled=true` 的 mech。** `ai.enabled` 仍控制注意力开关，它不会把 mech 改成采用本版移动偏好的档位；mech 原有视野、变向、策略和游戏物理约束继续生效。

## 原有设置与策略继续使用

`set-difficulty.cmd` 的菜单、操作步骤、命令行参数和保存方式保持不变。默认 JSON、四项玩家能力参数、输入映射与原生 1P key 校验保持，不需要增加任何新配置才能使用本版。没有扩大注意力容量、恢复额度或视野，也没有引入可信度打分或随机失误。

unlimited/infinite 默认 `plan_interval=1`，其他档位和 custom 默认 6；旧 JSON 中的显式值继续优先，菜单仍保留该字段。低速偏好不提高角色移速、不增加变向额度，也不更改预设名称与固定存活时间之间的关系；难度仍不保证固定存活秒数。

3.7 的有限感知保命 C2、灵梦 C1 修复、毒减速与激光几何模型保留。新的路线和快慢速选择可能间接改变后续压力与放 C 时机，不能理解成所有旧动作逐帧相同。AI=2P 和空 `side_key` 仍为公开默认；3.6.1 的原生授权实现与合法 key 沿用，公开文件不包含私有 key。

## 日志与验证范围

调试 CSV 保留 3.7 的前 197 列及顺序，在末尾追加移动偏好诊断，便于核对已纳入的近场密度、快慢保持、危险打断和路线缓冲。日志中的未知值不表示已确认安全，也不会反过来提供额外感知。

验证关注非 mech 的密度进入/退出、快慢保持与危险打断、安全路线余量、mech 完全旁路，以及旧注意力、菜单、输入与 C 策略兼容。实际完成的测试和计数以本次交付报告为准；本页不把既有 3.7 或 3.6.1 的验证结果当成 3.8 新测试结果，也不声称已经完成新版实战验收。

目标包为 `DS-TH09-AI-v3.8.0-test.zip`。继续使用原构建和随包源码重建入口，无需有效 1P key 即可构建。发布时整包匹配使用，不要单独混换 Lua 或运行库。

---

# 3.7 及更早历史说明

以下保留历史版本原文；旧版“不改变避弹路线”及日志列数等说明仅对应其标注版本，当前移动行为以本页顶部 3.8 说明为准。

# DS-TH09-AI 3.7.0-test

## 3.7 保命 C2 与设置兼容

本版在视野和注意力限制内提前准备保命 C2。普通放 C 仍追求连爆收益；当可见威胁持续挤满注意力、补充额度不足，或已识别威胁下可走的安全方向很少时，可以在实际储量至少 200 的前提下，为生存启动 C2，允许这次没有理想的连爆收益。

救场复用原有蓄力、释放和恢复流程，记录独立原因并锁定一次准备，避免压力短暂变化导致反复取消。充能完成不等于已经无敌：仍遵守动作门、C1 动作、实际蓄力重置和原生释放确认；未确认会超时退出，释放后有冷却。没有能量、已来不及蓄力或通道封死时仍可能中弹。

判断不读取圈外目标，也不用未纳入注意力对象的精确碰撞时间。避弹路线、毒雾减速、激光几何和四项玩家能力参数保持原规则；救场会改变部分场景的放 C 时机，包括对毒场景，不承诺逐帧动作与旧版完全相同。所有角色共用策略，没有对文特判。

### 原设置菜单继续使用

双击 `set-difficulty.cmd` 的操作、菜单项目、命令行参数和保存方式均保持。仍可设置难度、每秒变向、视野半径及注意力容量/恢复。新包默认 human200、AI=2P、debug_log=false，合法 1P key 与 3.6.1 相同，公开配置中的 key 为空。原生授权模块及输入映射没有更改。

根据人工对照测试，本版将 **unlimited（包括 infinite 别名）默认 plan_interval 设为 1**；其他档位、custom、未知档位回退及无运行配置的 Lua 默认使用 6。新默认 JSON 不再写全局 plan_interval，因此菜单切档会自然选中对应默认值。移动、视野、注意力容量/恢复数值没有提高。

已有 JSON 如果明确写着 `"plan_interval": 6` 或其他有效值，仍优先使用该值，菜单不会删除或改写。希望采用新版档位默认值时，只删除 ai 对象内的 plan_interval 一项，注意相邻逗号；也可以在 unlimited 配置中明确写 1。人工测试未发现可感知的水平变化，不代表所有弹幕下 1 与 6 等效。后续比较请使用同一配置。

### 日志与验证范围

CSV 保留原 182 列的名称和位置，在末尾增加 15 列，共 197 列：救场状态、原因、压力持续量、年龄、C2 准备更新数、已知 TTC、是否已迟、冷却、确认、尝试/释放次数及当前路线证据。`rescue_known_ttc` 是策略使用的上一回调证据，扣除一次更新后按当前 timeScale 换算为预计更新次数；`rescue_route_ttc` 是本回调最终路线的证据，仍为游戏计时单位。-1 表示未知。准备值同样使用 AI 更新次数，充满不代表保护已生效。TTC 都是短时预测估计，不是实际命中倒计时；原有动态激光估速和慢速时钟近似仍保留。日志不会反过来驱动决策，也不是完整逐帧回放。

测试包括低压不浪费能量、压力进入/滞回、真实能量和动作门、C1 转入 C2、释放确认/超时/恢复、暂停/受击/新轮清理，以及圈外和未跟踪对象不能泄漏精确 TTC。毒和激光回归、设置菜单、JSON 到运行 Lua、公开包及独立源码重建分别验证。具体通过计数以本次交付报告为准。

离线测试不代表已经解决所有对文早死场景，也没有重新标定各难度存活秒数。请完整解压新包实战复测，保留日志观察是否减少“有能量但 C2 准备太晚”的受击，以及是否因救场过多提前耗尽能量。

目标包 `DS-TH09-AI-v3.7.0-test.zip`。源码构建仍使用 `build-native.ps1` 和 `build-public-package.ps1`；随包源码通过 `rebuild-from-package.ps1` 及原 TinyCC 工具链重建。构建无需有效 key。

---

# 3.6.1 及更早历史说明

以下旧版的扫描默认值和无救场策略说明，以本页顶部 3.7 说明为准。

# DS-TH09-AI 3.6.1-test

## 3.6.1修正的是脚本绕过

3.6的慢哈希提高了猜key成本，但授权决定仍在可编辑的PowerShell中。本版保留3.6指定的新key和PBKDF2参数，并把检查放入原生启动器、支持模块和最终1P写键入口。

- 正常启动时，脚本仍先检查key；缺失/错误则按原规则配置实际2P。
- 原生启动器在创建游戏进程前独立验证key。删除脚本检查、伪造1P INI或直接运行启动器，不能跳过此验证；这种被篡改的启动请求会拒绝启动，不悄悄执行1P。
- 游戏内的原生支持模块再次独立验证。只有实际1P、key正确且输入/传感器/保护初始化全部成功，才发布本进程的只读授权结果。
- 发行 `inject.dll` 的1P写键入口会检查该结果。缺少支持模块/导出、授权失败或只启用2P时，都不执行1P写键。因此改INI、换上游启动器或单独加载本版注入DLL，也不会直接获得1P控制。已有2P写键与键位逻辑保留。

新增入口检查由公开的构建工具根据已验证的原版DLL确定性生成，保留原有函数RVA；随包源码能独立重建并校验它。不要混用旧inject.dll或window_support.dll，整包解压使用。

key只经短暂的进程环境传给原生模块，不写入命令行、INI、Lua、日志或额外授权文件。原生模块自行计算PBKDF2，不信任脚本传来的布尔值或公开摘要。父进程创建子进程后清除传递变量，支持模块验证后清除其副本；不声称能防同权限进程读取内存。

合法key无需更换。公开默认仍为 `ai.side=2, ai.side_key=""`；启用1P时在已有JSON的ai对象中填 `side=1` 和3.6指定的新key。key精确匹配，新增拒绝NUL字符，避免环境传递截断和HMAC尾部零字节等价。校验仅在启动阶段执行，战斗中只是轻量授权状态检查。Windows PowerShell5.1/.NET Framework4.7.2+要求保留，原生使用Windows CNG。

这版覆盖修改脚本/INI、换入口时对本版原生模块的绕过。重编译源码、替换/修改DLL、直接改进程内存、使用旧包或另写AI仍可另行绕过，本地公开源码程序不能对此提供不可撤销授权保证。

## 难度基线保持不变

没有修改plan_interval，没有按对手角色切换参数。发行配置仍为6；移动预算、圆形视野、注意力容量/恢复以及避弹、对毒、放C逻辑均保持3.6。日志版本号更新为3.6.1，列数仍182。

把plan_interval从6改为1会缩短新目标进入避弹判断的等待，属于能力设定变化。即使另外四项参数不变，也应视为不同的参数基线；只对文改变它，不能拿来宣称原档位的统一基线没变。此前报告仅提出对照实验，本版没有替你执行这项调整。

## 构建和验证范围

目标包 `DS-TH09-AI-v3.6.1-test.zip`。开发目录运行build-native.ps1，再运行build-public-package.ps1（Version为3.6.1-test）；完整解压包可在source目录运行rebuild-from-package.ps1并提供完整TinyCC0.9.27 win32的CompilerPath。构建无须有效key。

验证包含篡改脚本/INI、父启动器检查被跳过时的支持模块拒绝、真实x86写键入口拒绝/授权路径、原参数与输入回归、独立源码重建。本轮不运行游戏主线程，实际计数见交付验证说明；不以离线测试代替实战验收。

---

# 3.6及更早历史说明

旧版本的“仅脚本门槛”和未修改原生模块描述不适用于3.6.1。

# DS-TH09-AI 3.6.0-test

## 本版变化

基于3.5，轮换1P配置key并加强启动校验，同时补充对文等高速压力场景的诊断。灵梦C1修复保留；本版没有调整避弹、放C、毒处理或四项能力参数，不代表已经修好对文的生存表现。

### 1P配置key

请求 `ai.side=1` 时使用本次重新指定的key，旧key在3.6中不再有效。源码只保存随机盐及 PBKDF2-HMAC-SHA256 校验结果，迭代600000次；不保存key明文，也不回退到旧的快速SHA256校验。旧包保持原样，不会因本版发布自动撤销其中的旧key。

公开默认仍为 `ai.side=2, ai.side_key=""`。需要1P时，关闭游戏，在已有 `launcher-settings.json` 的 `ai` 对象内填写 `side=1` 及新的 `side_key`；区分大小写，空格也参与校验。不要分享已填私人key的配置。启动时显示的实际接管侧为准。

缺失、错误、非字符串或超长key回退实际2P，不改保存的JSON；side本身仍必须是整数1或2。实际侧继续决定唯一AI输入、真人侧、Charge Type=Slow要求和1P练习保护：实际AI为1P时不为AI开启练习保护，回退2P时按原设置保护真人1P。

1P校验需要 Windows PowerShell 5.1 及 .NET Framework 4.7.2或更新版本；缺少所需加密API或加密失败时回退2P，不降级为弱校验。600000次计算只在请求1P的启动阶段执行，本机测得约1.4～1.7秒；2P跳过，战斗期间不计算。逐字节比较没有提前退出，但不宣称PowerShell执行具有严格恒定时间。

这是提高离线猜测成本的本地门槛。持有源码者仍能改掉检查，它不提供在线授权或防篡改保护。

### 日志增强

开启 `ai.debug_log=true` 后，CSV共182列，3.5的前169列名称和顺序不变。尾部追加版本、实际AI侧、双方角色编号、实际扫描间隔、是否扫描、未跟踪目标计数、信用/容量拒绝计数、恐慌状态，以及蓄力速度、预热更新数和时间比例。角色未知记为-1；缺失的时间信息留空。

出现/消失紧急盲弹、过载状态变化、移动风险变化时增加记录，仍保留原来的周期和动作/受击记录。它不是逐帧录像，也没有记录致命子弹ID或完整命中前缓存。`attention_waiting_scan_count` 是未扫描回调中当前相关但未跟踪的目标数，不表示扫描间隔是唯一原因；信用与容量拒绝按实际扫描时的纳入结果计数，两者可以重叠。

### 对文的对照测试

已有日志确认两轮对文首次受击约113、120秒，一轮对毒约167秒；文的6次受击中5次记录到紧急盲弹，也有储量足够但C2尚未蓄好的窗口。日志无法确定每次具体致命对象，不能据此把所有死亡归因于注意力。

默认 `plan_interval=6` 保留。建议另存一份对文测试配置，仅把已有 `ai.plan_interval` 改为1，保持 unlimited、移动预算6、圆形视野149.3333、注意力容量120/恢复90不变，并使用相同双方角色作多轮对照。它缩短新目标纳入的等待，不增加注意力额度，不保证解决信用耗尽或C2准备过晚。对毒继续使用原配置。

本版离线与挂起验证不代替实战验收；实际验证数字见本次交付的设置与验证报告。
## 构建3.6

开发源码目录使用完整TinyCC 0.9.27 win32工具链：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-native.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-public-package.ps1 -Version 3.6.0-test -PackageName DS-TH09-AI
```

下载包完整解压后，在 `source` 目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\rebuild-from-package.ps1 -CompilerPath 'C:\tools\tcc\tcc.exe' -Version 3.6.0-test
```

目标包 `DS-TH09-AI-v3.6.0-test.zip`。完整解压使用，不覆盖旧包；公开配置key保持空串。构建本身不需要有效key。3.6没有原生C/H改动，原生只读快照与输入行为承接3.5。

---

# 3.5及更早版本历史说明

以下只适用于对应历史版本；旧SHA256 key规则由上方3.6规则取代。

# DS-TH09-AI 3.5.0-test

## 本版变化

3.5 基于已验收的 3.4 继续开发，处理灵梦 C1 相关问题，并给 1P AI 接管增加本地配置 key 门槛。原有两侧键位、四项能力参数和默认 2P 接管方式保留。

灵梦 C1 现在区分“预测碰到”与“预计足以起爆”：读取同一个目标的实际血量、受伤状态及固灵状态，结合符札伤害、追踪路径和首次碰撞判断。单张伤害不足不会凭空计整条连爆；前方目标消耗的非贯穿符札不能再次给后方目标计算伤害。未固灵不能直接作为 C1 起爆种子，固灵准备仍须观察到同一目标实际激活，不能只因请求过 Shift 就视为成功。

预测计入剩余充能时间以及符札先展开、后追踪的过程；蓄力后持续复核原来的直接起爆目标。未满 C1 时目标失效可取消，蓄满后只作有界等待，并防止误升 C2。原有期限型 C1 和 C2 的独立规则保留，不把有意的期限释放误报为可靠连爆收益。

新增读取和估计不会改写游戏血量、判定或子弹。避弹与 C 目标继续受同一圆形视野限制，Shift 仍服从实际避弹输出和原来的时间预算。预测只使用当前可见目标及有限时间窗口；目标以后转向、消失、入场或特殊受伤状态仍可能令实际结果不同，本版不承诺每次 C1 必然打爆目标。

## 选择 AI 接管侧

关闭游戏，用记事本编辑 `launcher-settings.json` 中已经存在的 `ai` 对象，保留其他参数。默认字段为：

```json
"side": 2,
"side_key": ""
```

以上是对象内的字段片段，不是完整 JSON 文件；不要新建第二个 `ai` 对象或用片段覆盖整个设置文件。

- AI 在右侧 2P：保留 `"side": 2`，不需要 key。
- 请求 AI 在左侧 1P：设为 `"side": 1`，并把获得的 key 填入同一对象的 `side_key` 字符串。key 区分大小写，不自动去掉首尾空白。
- 请求 1P 时，key 缺失、错误或不是字符串，启动器会提示本次改用 2P AI。原文件中的 `side`、`side_key` 和练习设置保持不变。
- `side` 缺失时按 2P 处理。`side` 本身仍只允许数字 `1` 或 `2`；其他值或字符串 `"1"`／`"2"` 会报错停止启动，不会按 key 回退规则放行。

更改后重新运行启动脚本。以启动控制台显示的**实际接管侧**为准：

| 保存的请求 | key 状态 | 实际 AI 侧 | 玩家侧 | 必须使用 `Charge Type = Slow` 的一侧 |
| --- | --- | --- | --- | --- |
| `side=2` 或未设置 | 不要求 | 2P | 1P | 2P |
| `side=1` | 正确 | 1P | 2P | 1P |
| `side=1` | 缺失／错误／类型不符 | 2P | 1P | 2P |

玩家侧可保留自己的 Charge Type。它与 Key Config 的键盘 Type 是不同设置。

`side_key` 只参与启动器的本地判断，不传入生成的 INI 或 Lua 设置，也不在启动提示和日志中显示。公开默认值为空，代码保存校验摘要。这是**本地配置门槛，不是在线账号授权**；能修改源码的人可以修改或绕过该判断，因此不把它当作远程权限或防篡改机制。

`ai.enabled` 仍然是注意力限制的开关，不表示启用或停用机器人接管。

## 键位和输入隔离

本版不改输入映射：

| 用途 | 左侧 1P | 右侧 2P |
| --- | --- | --- |
| 移动／选人 | 方向键 | W、A、S、D |
| 射击／确认 | Z | J |
| 特殊攻击／取消 | X | K |
| 慢速 | Shift | L |

菜单和选人仍使用这些按键。战斗中仅实际 AI 侧由机器人独占，另一侧由玩家正常操作；机器人达到操作时限后保持停键，不自动交回物理键盘。1P 的 FULL 与 2P 的 LEFT 配置方式沿用 3.4，不要在 AI 运行期间更改 Key Config Type。

## 练习保护跟随实际接管结果

旧字段 `practice.player1_no_damage` 和 `practice.player1_invincible` 始终只表示左侧 1P，没有新增 2P 练习保护。

- 实际 AI 为 2P：1P 是玩家，按保存的配置应用 1P 练习保护，包括请求 1P 但 key 未通过的回退情况。
- 实际 AI 为 1P：自动抑制两个 1P 练习开关的生效，防止保护机器人。原 JSON 值保留，也不会转移为保护右侧玩家。

因此 Slow 模式要求、输入独占和练习保护都按实际接管侧处理，不单看文件里请求的 `side` 数字。

## 原有四项能力设置

| 能力 | 字段 | 默认值与范围 |
| --- | --- | --- |
| 每秒避弹变向上限 | `ai.move_change_budget` | 默认 6，整数 1～10 |
| 自机圆形视野半径 | `ai.vision_radius` | 默认 149.333333333333（448/3），范围 16～640 |
| 注意力容量 | `ai.attention_capacity` | 跟随预设，范围 1～256 |
| 每秒新纳入注意力额度 | `ai.attention_recovery_per_second` | 跟随预设，范围 0.1～256 |

双击 `set-difficulty.cmd` 可以切换预设或调整四项能力；修改和保存难度时保留 `side` 与 `side_key`。切换预设会清除两个手动注意力覆盖，保留视野、变向和其他设置。

默认 `human200` 的注意力容量／新纳入额度为 26／19；`human240` 为 32／24，`human300` 为 40／30，`human480` 为 55／40，`unlimited` 为 120／90。`mech` 默认关闭注意力限制，但仍保留圆形视野和变向上限。预设名称不保证相应的实战存活秒数。

视野以 AI 自机为圆心，采用游戏坐标单位，与窗口像素大小无关。避弹和放 C 的目标、连爆收益及压力判断受同一个圆限制；形状伸入圆内的长激光／长条 EX 仍可见。“每秒”沿用 60 次战斗回调滚动窗口；持续同向移动不重复计数。

## 安装与使用

保留整个 `DS-TH09-AI` 文件夹，放在支持的日文原版 TH09 v1.50a 游戏目录附近，关闭游戏后编辑设置，再运行 `启动TH09-AI.cmd`。进入 `Match Mode → 人间 对 人间`，确认实际 AI 侧为 Slow 后开始对战。

升级应使用完整匹配版本；不要只替换 Lua 或单个原生模块。保留已有 3.4 及更早 ZIP 作为回退副本。默认操作期限和窗口设置沿用之前版本。

## 构建 3.5

在开发源码目录用完整 TinyCC 0.9.27 win32 工具链执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-native.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\build-public-package.ps1 -Version 3.5.0-test -PackageName DS-TH09-AI
```

下载包完整解压后，在其 `source` 目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\rebuild-from-package.ps1 -CompilerPath 'C:\tools\tcc\tcc.exe' -Version 3.5.0-test
```

新 `enemy_sensor.c/.h` 和 `enemy_sensor_selftest.c` 必须随包提供并参与构建；旧ZIP不覆盖。公开默认 `side=2`、`side_key=""`，不得将有效key放进公开配置、文档或测试样例。
## 诊断与验证范围

调试 CSV 共 169 列，3.4 的前162列顺序不变；尾部新增 C1 准备延迟、伤害模型／战斗快照有效性、血量否决、符札阻挡、锁定种子和等待年龄等信息。反馈时附上双方角色、实际AI侧、Charge Type及本版日志；不要公开包含私人key的设置文件。

本版通过相关 Lua 回归、只读原生快照／x86桥接与双侧挂起测试；原包和独立目录的随包源码重建均须执行发行校验。详细实际数字以本轮交付验证记录为准，不沿用下方历史版本计数。挂起检查不执行游戏主线程，本轮开发验证不等同于实战验收。

目标包：`DS-TH09-AI-v3.5.0-test.zip`。必须整包使用，不混装3.4的原生模块。

---

# 3.4 及更早版本的历史原文

以下内容只作对应版本参考；1P 无 key 的旧行为已被3.5上方规则取代。

# DS-TH09-AI 3.4.0-test

本版基于 3.3.0-test 增加 AI 接管侧选择。在 `launcher-settings.json` 已有的 `ai` 对象内添加或修改 `"side": 1`（AI 控制 1P）或 `"side": 2`（AI 控制 2P，默认）。保留其他配置，不要再建第二个 `ai` 对象。

| `ai.side` | AI 控制 | 玩家控制 | 必须设为 `Charge Type = Slow` 的一侧 |
| --- | --- | --- | --- |
| `1` | 左侧 1P | 右侧 2P | 1P |
| `2`（默认） | 右侧 2P | 左侧 1P | 2P |

`side` 只接受不加引号的数字 `1` 或 `2`；旧配置没有这一项时按 `2` 处理。非法值会阻止启动并提示修改。关闭游戏后修改，重新运行启动脚本才生效。玩家一侧可保留自己的 Charge Type。

## 按键与输入隔离

接管侧选择不改变两侧按键：

| 用途 | 左侧 1P | 右侧 2P |
| --- | --- | --- |
| 移动／选人 | 方向键 | W、A、S、D |
| 射击／确认 | Z | J |
| 特殊攻击／取消 | X | K |
| 慢速 | Shift | L |

菜单与选人仍由上述物理键操作。进入战斗后，只有配置选中的 AI 侧输入由 AI 独占；另一侧继续响应玩家的物理按键。达到 AI 操作时限后，选中侧仍保持停键，不会自动交还给键盘。AI 代码中的 Z 是射击动作，与键盘上的物理 Z/J 无关。

原来的键盘模式要求保持：1P 使用 `FULL`，2P 使用启动器配置的 `LEFT`；本次进程中的 LEFT 仍映射为 WASD/J/K/L。不要在 AI 运行中修改 Key Config 的 Type。Charge Type 与 Key Config Type 是不同设置。

## 1P 练习保护

`practice.player1_no_damage` 和 `practice.player1_invincible` 始终表示左侧 1P，不会随玩家换侧而改成保护 2P。

- `ai.side=2`：1P 是玩家，两个练习开关沿用原有行为；两者同时开启时以 `player1_invincible` 为准。
- `ai.side=1`：1P 是机器人，为避免给 AI 练习保护，启动器自动抑制这两个开关的实际生效，并在控制台说明；JSON 中保存的值仍保留，切回 `ai.side=2` 时恢复按配置应用。
- 本版没有新增 2P 练习保护。

## 延续 3.3 的能力与策略

避弹、放 C、能量经营、移动限制、圆形视野和注意力参数沿用 3.3；切换接管侧不会改变难度预设。CSV 保持 162 列。继续支持自定义能力，不承诺预设名中的数字等于实战存活秒数。

| 可调能力 | JSON 字段 | 默认与范围 |
| --- | --- | --- |
| 每秒避弹变向上限 | `ai.move_change_budget` | 默认 6，整数 1～10 |
| 自机圆形视野半径 | `ai.vision_radius` | 默认 149.333333333333（448/3），范围 16～640 |
| 注意力容量 | `ai.attention_capacity` | 默认跟随预设，范围 1～256 |
| 每秒新纳入注意力额度 | `ai.attention_recovery_per_second` | 默认跟随预设，范围 0.1～256 |

| 预设 | 注意力容量 | 每秒新纳入额度 |
| --- | --- | --- |
| `human200` | 26 | 19 |
| `human240` | 32 | 24 |
| `human300` | 40 | 30 |
| `human480` | 55 | 40 |
| `unlimited` | 120 | 90 |
| `mech` | 默认关闭注意力限制 | 默认关闭注意力限制 |

`human600` 不是当前预设。`unlimited` 仍有有限注意力预算；`mech` 默认只关闭注意力限制，圆形视野和变向上限继续有效。注意力采用速度、形状加权成本，不等于子弹颗数；手动注意力值优先于普通预设。双击 `set-difficulty.cmd` 可调四项能力和切换预设；切预设会清除两个手动注意力覆盖，保留接管侧、视野、变向及其他设置。

视野以 AI 自机为圆心，单位为游戏坐标，与窗口像素大小无关；避弹和放 C 的目标、连爆收益与压力判断均受该圆限制，长激光／长条 EX 的当前真实形状与圆相交即可感知。自己的气槽、动作门、保护及对手气槽读取保持正常。“每秒”指 60 次战斗回调滚动窗口，限制被感知危险中的方向切换；持续向同一方向移动不重复计数，圆形视野也不限制行走距离。

## 安装与启动

只支持日文原版 TH09 v1.50a，本包不含游戏。解压时保留整个 `DS-TH09-AI` 文件夹及其中的 `ai`、`runtime`、`source`、`licenses` 和配置文件，把它放在 `th09.exe` 附近的下级目录。启动器向上查找最近的 `th09.exe`，会检查版本；不支持与 thprac、vpatch、Adonis 等注入工具混用。

1. 游戏关闭时编辑 `DS-TH09-AI/launcher-settings.json`，选择 `ai.side`。
2. 双击 `DS-TH09-AI/启动TH09-AI.cmd`。
3. 将选中的 AI 侧 `Charge Type` 设为 `Slow`，玩家侧保留自己的设置。
4. 进入 `Match Mode → 人间 对 人间`，分别选人；开战后 AI 接管配置的一侧。

不要只更换 Lua 或原生模块；3.4 必须整包使用。不要手动编辑启动器生成的 `ai/runtime-settings.lua` 和 `runtime/ka_ai_duka.ini`，它们会在下次启动时重新生成。

默认操作期限仍是最外层 `seconds=600`，整数 0～86400，0 不限时；按战斗回调/60 计时，分轮不会重新获得一份期限。窗口默认 960×720、可拖动边角并保持 4:3。窗口和练习设置仍可在同一 JSON 中修改。

JSON 不支持注释，末尾不要多加逗号。启用 `ai.debug_log` 可记录 CSV；反馈换侧问题时请同时提供 `ai.side`、双方角色和 Charge Type、`VERSION.txt`、启动控制台文字及相关日志。

## 构建 3.4.0-test

使用 Windows PowerShell 和完整 TinyCC 0.9.27 win32/i386 工具目录。开发工程中先构建原生模块，再显式指定版本与包名：

```powershell
.\build-native.ps1
.\build-public-package.ps1 -Version 3.4.0-test -PackageName DS-TH09-AI
```

从完整发行包的 `DS-TH09-AI/source` 目录重建：

```powershell
.\rebuild-from-package.ps1 -CompilerPath '<完整 TinyCC win32 安装中的 tcc.exe 路径>' -Version 3.4.0-test
```

不要仅复制 `tcc.exe`，它需要相邻的 include、lib 和运行库文件。保留外层 `DS-TH09-AI` 名称，重建脚本从该目录识别包名。构建输出另存为 `DS-TH09-AI-v3.4.0-test.zip`，保留原来的 3.3 与更早 ZIP；构建本身不安装或启动游戏。

## 本轮验证状态

3.4.0-test 已通过 292 项启动配置检查、1330 项 Lua 双侧集成检查、131072 项原生双侧输入用例，以及各 18 项原生配置边界和挂起启动检查；原有启动、路径、能力设置、计时、窗口和传感器回归通过。检查覆盖旧配置默认 2P、反复换侧、错误参数、真人侧输入保留及 1P 练习保护抑制。使用独立复制的测试文件，挂起启动未执行游戏主线程；本轮未进行实战验收。下方旧版本 PASS 数量只属于相应历史版本。

目标发行包：`DS-TH09-AI-v3.4.0-test.zip`。

---

# 3.3 及更早版本的历史原文

以下内容完整保留以便追溯旧版本；其中固定“1P 玩家／2P AI”、旧包名、默认值、CSV 列数、测试结果和命令均属于当时版本。3.4 的当前用法、接管侧和练习保护以上文为准。历史说明不能覆盖当前配置。

# DS-TH09-AI 3.3.0-test

本版将视野、注意力和避弹变向上限开放给玩家，暂缓按固定生存秒数标定难度；原预设名称继续兼容。

双击 `set-difficulty.cmd` 打开中文能力设置菜单，可以修改数值、切换预设、保存或放弃修改。下次通过启动脚本启动时生效。

| 设置 | 默认值 | 可调范围 |
| --- | --- | --- |
| 每秒避弹变向上限 | 6 | 1～10，整数 |
| 视野半径 | 149.333333333333 | 16～640 |
| 注意力容量 | 跟随预设；human200 为 26 | 1～256 |
| 每秒新纳入注意力额度 | 跟随预设；human200 为 19 | 0.1～256 |

视野以自机为圆心，默认半径为单侧游戏场地高度 448 的三分之一，使用游戏坐标单位，独立于窗口像素大小。避弹、放 C 的起爆目标、连爆收益与压力判断都只读取圈内对象。只要长激光／长条 EX 的真实当前形状伸进圆内就能看见；圈外对象不会因未来可能飞入而提前可见。已经跟踪的对象离圈后立即退出判断，视野圈随自机移动。自己的气槽、动作门、保护和对手气槽等状态读取保持正常。

“每秒”沿用 60 次战斗回调滚动窗口（正常 60Hz 约一秒），限制被感知危险下的方向切换；持续向同一方向移动不重复计数，平静走位不消耗该预算。原有最短变向间隔继续生效，因此开放到 10。圆形视野约束可用信息，连续移动仍可横穿场地。

注意力容量控制同时跟踪的威胁总成本；每秒新纳入额度控制发现新目标的速度。它们是速度、形状加权的威胁单位，不等于物理子弹颗数。激光、毒云和敌人沿用原有免预算处理，但同样受圆形视野限制。调低注意力会增加漏看，已有压力反馈仍受真实能量和蓄力动作门约束，不保证必放 C 或必定存活。

手动设置的注意力值优先于普通预设；通过菜单切换预设会清除这两个手动覆盖，保留视野、变向和其他设置。mech 默认关闭注意力限制，视野与变向仍有效；不再把 human200／300／480 名称作为存活秒数承诺。

也可在 `launcher-settings.json` 的现有 `ai` 对象中修改：

```json
{
  "difficulty": "human200",
  "move_change_budget": 6,
  "vision_radius": 149.333333333333,
  "attention_capacity": 26,
  "attention_recovery_per_second": 19
}
```

默认发行配置不写死两个注意力覆盖值，以便切换预设直接生效。手动只设置其中一个时，另一个继续跟随预设。原有 `sight_radius` 是近身威胁相关性参数，新圆形视野参数是 `vision_radius`。

CSV 扩为 162 列，前 149 个字段位置保持，追加视野半径、圈内／圈外对象数、实际变向预算和注意力设置。原始 bullets/enemies/ex_attacks 数量用于诊断对照；field_erasable 及链条收益现在来自圈内快照。保留 3.2.5 的计时、分轮与有界 C1 保蓄优化。

验证：30 套 Lua 回归通过，含硬圆视野 129 断言、玩家参数 12 场景／402 断言、真实主循环视野集成 9 场景／632 断言及 162 列 CSV。Windows PowerShell 5.1 设置菜单 67 项通过；实际 JSON→启动器→runtime→Lua 为 13 场景／413 断言，另有 27 项启动器边界检查。原生构建／自测通过，含 player sensor 58357 项。发行包与随包源码重建验收见最终交付记录。

发行包名称：`DS-TH09-AI-v3.3.0-test.zip`。旧发行包保留，2.0 不变。离线验证不代替实战测试。

---

以下为 3.2.5 及更早历史记录；当前参数、列数和范围以上文为准。

# DS-TH09-AI 3.2.5-test

本版修正开花计时、分轮状态与接近 C2 时的蓄力决策，保留 3.2.4 的视野身份和真实形状修复。

晚期开花的 180 秒现在对应 10800 个游戏 Timer 单位；切入与时停不累计有效时间。CSV 的 `battle_seconds` 改为真正的游戏秒数，旧日志同名列记录的是 Timer 单位，比较旧数据时须先除以 60。

检测到有效的 state5 分轮信号时，清除上一轮的规划、跟踪与统计缓存；整个接管会话的操作期限继续累计，不因分轮重新获得一份时限。CSV 扩为 149 列，原 134 个字段的名称和位序不变，新字段追加；`battle_seconds` 的单位修正是明确的语义变化。

C1 接近 C2 时只允许有界等待：必须已经持有蓄力、stock 至少 190，且连续 3 次观察到真实 stock 正增，C2 有用途，并按观测趋势预计 18 个 Timer 单位内能达到 200，才保留这次蓄力短暂等待。回能停止、动作门关闭、暂停、受击或达到等待上限都会退出；只有实际观察到 stock 达到 200 才能升级 C2。趋势不是回能来源或未来收益的保证，不能据此承诺必达 200 或必能保命。

当前 C1 模型把妖精和已固灵作为直接起爆候选；未固灵不能作为 C1 直接种子，但可作为已起爆连通链的潜在爆风中继。几何覆盖、链条收益与回能都不是确认击杀。新增回归约束的是当前模型规则，不证明所有角色真实 C1 都必杀或都不能直接打未固灵。

难度预算、新目标 6 帧纳入扫描设置与移动限制不变：human200 仍为同时跟踪 26／每秒新纳入 19，human300 为 40／30。扫描之间仍逐回调绑定已跟踪对象和刷新当前诊断。200／300 秒是待实战校准目标；本版不调整 2.0 或已有发行 ZIP。

验证：27 套 Lua 回归通过，包括 C1 目标语义 39 断言、分轮与诊断 129 断言、C2 保蓄 25 场景／367 断言、计时与阈值 8 场景／41 断言，以及 149 列 CSV、精简宿主和视野回归。原生构建与自测通过，含 player sensor 58357 项。发行包与随包源码重建的最终校验结果见交付验证报告；离线通过不等于实战存活时间已达标。

发行名称继续使用 `DS-TH09-AI`，目标文件为 `DS-TH09-AI-v3.2.5-test.zip`。

源码构建显式指定版本与包名：

```powershell
.\build-public-package.ps1 -Version 3.2.5-test -PackageName DS-TH09-AI
```

完整公开包在 `DS-TH09-AI/source` 内重建：

```powershell
.\rebuild-from-package.ps1 -CompilerPath '<完整 TinyCC win32 安装中的 tcc.exe 路径>' -Version 3.2.5-test
```

替换编译器占位符，保留外层 `DS-TH09-AI` 名称与完整目录结构；脚本从外层目录识别包名。构建脚本的旧默认版本不代表本版，须显式传入上述版本。

## 3.2.4 与更早版本记录

以下原文保留用于追溯；旧版参数、单位、列数、版本号和测试结论不表示 3.2.5 的现行结果，当前行为以上述说明为准。

# DS-TH09-AI 3.2.4-test

本版修复两处注意力视野问题：已跟踪对象按稳定 ID 在每次回调绑定到当前快照；视野相关性与避弹路线统一使用真实形状的扫掠边界，避免长条 EX 被中心／半径近似漏掉。新目标仍受扫描间隔、纳入额度和注意力预算限制；两次纳入扫描之间的当前诊断也逐回调更新。

本轮不调整难度数值：human200 仍为同时跟踪 26／每秒新纳入 19，human300 仍为 40／30。C 策略、阈值、移动限速和 134 列 CSV 格式保持。200／300 秒仍是待实战标定的目标，不能把修复或 mech 长局统计视为已达到目标的证明。

已完成 23 套 Lua 回归，包括新增 `attention_identity_geometry_test.lua` 的 14 场景／186 断言、既有注意力 91 断言、精简运行环境、主循环 134 列 CSV 和毒／激光覆盖；原生构建自测通过，含 player sensor 58357 项。最终打包／源码重建校验待本轮交付记录确认。本轮不改 2.0、不安装、不启动游戏。

沿用 `DS-TH09-AI` 名称以兼容旧安装，发行文件名为 `DS-TH09-AI-v3.2.4-test.zip`。

源码构建显式指定本版和包名：

```powershell
.\build-public-package.ps1 -Version 3.2.4-test -PackageName DS-TH09-AI
```

从完整公开包的 `source` 目录重建时，运行 `rebuild-from-package.ps1 -CompilerPath <本机完整 TinyCC win32 安装中的 tcc.exe 路径> -Version 3.2.4-test`，将占位符替换为实际编译器路径。脚本从外层目录识别 `DS-TH09-AI` 包名，请保留完整 `DS-TH09-AI/source` 目录结构。

## 历史说明

下文保留旧版背景；旧版本号、默认值、包名示例、诊断列数及测试结论仅作历史参考，当前版本以上述说明为准。

# TH09-AI

TH09-AI is a local 2P AI package for Touhou Kaeidzuka / Phantasmagoria of
Flower View v1.50a. It uses the redistributable ka_ai_duka v1.7 runtime and a new
Lua decision layer under `src/ai`.

Author: 圣诞老人的驯鹿-xunlu. The Chinese player manual is
`dist/TH09-AI/README.md`. Version 2.0.5 is the bloom follow-up test release. It replaces
random C1-C4 and the 500,000-point firing lock with resource-aware C1/C2 play
for every character, retaining the established poison and laser avoidance.
Run `build-public-package.ps1` for a release that
includes the project source and third-party notices.

## Capture approach and C2 follow-up (2.0.5)

All characters retain deterministic bloom behavior, short selective Shift
windows and high-speed fairy supply. The observer now evaluates spirit capture
separately from ordinary ignition, including its connected chain and nearby
white bullets. A useful off-axis capture gets a bounded high-speed approach
before Shift; an existing preparation lock no longer prevents capture after
alignment. Merely having 200 energy cannot overwrite that goal with an
unprofitable C2 position. Approach is bounded at 60 updates with retry spacing;
the retained whole preparation/shape wait remains bounded at 90 updates.

Read-only C1 information combines the current role's selector-1 firing records
with current AABBs belonging to those records. Supported generic templates
contribute prospective coverage; supported active objects contribute only their
present geometry, and only damageReady objects can contribute a current hit.
Custom spawn/motion/hit callbacks can leave a partial model.
Unknown effects use limited coverage and existing fallbacks, not invented exact
all-character skill shapes. Current-action remainder cannot fund a new C1 charge.
A materially better fresh C1 return can beat an early C2; the C2 deadline wins.

After a C2 release request, charge reset plus associated new protection/common
wave observations establish a follow-up window. A useful Z edge may be requested
when canPressZ permits it, including pre-holding a planned next charge while its
separate action gate is closed. This has its own request counter; it is not a
second confirmed C1 release or proof that pressing Z respawns every C1 projectile.
Only live state-3 protection supplies safety; no release request grants 48 frames.

The normal fast interval remains 72 updates. A confirmed C2 window with enough
live protection may start a brief capture after 24 fast updates instead. Actual
Shift use stays capped at 40 per 180 updates and 32 per capture; alignment,
resources and action gates still apply. This exception does not keep Shift held.

Actual common circles are read with fixed centre, radius, growth, delay and
remaining lifetime. Conservative yield exclusion avoids budgeting whites likely
to be swallowed, but never removes hazards from dodge. Common type-1/type-4
effects are not exclusive C2 identifiers. isErasable describes explosion
resources and is not a verified C2-cancelability flag.

Confirmed follow-up movement keeps its original 12-update poisoned/wall-limited
trajectory. At normal time scale it may additionally check holding that actual
endpoint until conservative protection expiry plus four updates, bounded at 60.
It uses the same current collision-free, terrain and soft-risk candidate band;
no verified endpoint means immediate geometric evasion, not a safe-route claim.
This does not extrapolate the chosen direction throughout the entire shield or
weaken ordinary avoidance. Expiry contact, persistent EX/lasers and warning
lasers retain their geometry; neither a predicted circle nor unobserved next C2
grants safety. Above-limit height recovery and unsupported timing stay on the
existing path.

## Retained bloom bounds

The player stays at Y >= 150 (below roughly the top third), with original
physical bounds y=16..432. Ordinary-shot/C1 approach does not chase upward;
selective spirit capture remains height-limited. Actual-position obs.c2 and
at-most-nine lower/side proposals remain separate. Full search defaults to every
six observe calls; only coordinates are cached and actual yields are refreshed.
Early C2 normally needs net/(net+direct+contested) >= 0.35. Direct C2 erasure
gives neither recharge nor returned whites; enemy/spirit chains provide that
potential yield. Common C2 growth is 4, last active radius 188, lifetime 48;
the 192 contested envelope is a conservative accounting bound, not cleared space.

C2 has an independent 480-game-Timer deadline (eight seconds at normal speed).
C1 never resets it. Warm-up, remaining charge/speed and margin start charging
before the deadline; energy/action/hit gates may delay it while retaining debt.
Cut-ins/time stops freeze cadence. Optional shape holds stay within C2 200..299
or C1 100..199 and at most 24 updates. Urgency, preparation bounds, the deadline
or charged+chargeSpeed reaching the next level ends waiting. Current Max below
the next level is not permission to risk crossing it.

No X, random C selection, 500000-point firing lock, emergency danger-triggered
C, or deliberate C3/C4 is added. A refill to 2/3 is an observed outcome, not a
mandatory trigger or guaranteed continuation. Version 3.0 remains postponed.
Core player.sensor apiVersion stays 1; followupApiVersion=1 adds read-only data.
Game physics, spawn counts, energy and 2P protection are not modified.

Final 2.0.5 regression, packaging, source-rebuild and file-verification results
belong to this delivery's final validation record; this document does not
predeclare them passed. User live acceptance remains pending. Historical 2.0.2
acceptance and other old passes do not validate this version or guarantee FPS.

## License scope

The root MIT license applies to this project's original AI, launcher, native
helper source, build scripts and documentation. It does not relicense ka_ai_duka,
Lua, Boost, TinyCC runtime code, THprac material or the original Touhou game.
Third-party notices and exact applicable texts are in
`dist/TH09-AI/licenses/THIRD_PARTY_NOTICES.txt`. In particular, ka_ai_duka's author
permits redistribution with its LICENSE.txt; that file's Lua MIT notice is not
a blanket MIT grant for all of ka_ai_duka. The TinyCC startup code linked into
our EXE/DLL has separate LGPL terms; the public package includes corresponding
TinyCC source plus our buildable source and relinking instructions.

## Project layout

- `src/ai`: editable AI source.
- `dist/TH09-AI`: ready-to-copy test package.
- `vendor/ka_ai_duka-ver1.7-source`: exact upstream v1.7 source snapshot.
- `vendor/ka_ai_duka-src`: newer upstream master snapshot used for comparison.
- `vendor/ka_ai_duka_1_7_20150712.zip`: upstream release archive.

The package is designed to be copied as a `TH09-AI` subfolder beside
`th09.exe`. The launcher searches upward from its own parent directory for the
nearest `th09.exe`, allowing additional ZIP extraction wrapper directories.
It regenerates ka_ai_duka's absolute-path INI from the current location on every
launch, so moving the game/package does not retain an old installation path.

## Behavior contract

- Match Mode, Human vs Human, AI controls 2P.
- 2P must use the game's Option Charge Type = Slow: hold Z to charge and
  Shift for slow movement. The reversed Charge mode is unsupported; detecting
  it releases AI input and requests Slow mode. This does not change 1P's
  preference or add a JSON setting.
- Local limited-horizon bullet avoidance; it is intentionally not globally
  optimal and can be surrounded by converging C3 attacks.
- All characters use bloom behavior: observe fairy formations, inactive and
  activated spirits, and erasable bullets as connected spatial resources.
- Preserve useful formations until an ordinary shot, C1 or C2 can start a useful
  chain. Resource-qualified C2 is usual; a materially better fresh C1 yield
  can take priority before the C2 deadline, even with enough C2 energy.
- Only deliberately charge/release C1 or C2. There is no random C3/C4 selection,
  no Spell Point firing lock, and no X input. Natural score-triggered attacks
  generated by the game are not deliberate C3/C4 input.
- Plan the next C2 from explosion-converted resources and observed recharge;
  do not count white bullets swallowed directly by C2. Poor resources
  can mean waiting before the independent cadence deadline, even at risk of a
  hit. The deadline can override resource gates; danger never triggers emergency
  C2. Ordinary dodge remains active while waiting.
- Prefer high-speed mode to preserve fairy supply; use short low-speed windows
  when spirit capture is useful. Standing still does not require Shift. The
  user's three-teams-versus-one observation is an empirical design premise,
  not a verified spawn formula or a change to the game's spawn rules.
- Stop all AI input at the configured battle limit (600 seconds by default),
  remaining stopped until the next battle. Count AI battle callbacks / 60,
  not wall-clock time. A limit of 0 disables the timer. Pause-menu scheduling
  has not been separately verified and is controlled by the original game.
- Treat every zero-height laser record as a soft warning; add configurable
  virtual thickness only when the warning meets warning_laser_min_length.

## Laser perception correction (0.1.8)

The upstream Laser::Update export omits the raw.length1 offset when positioning
hitBody and reports laser vx/vy as zero. The new laser_sensor.c/.h support checks
the original runtime function and vtable before installing an in-memory export
hook during suspended startup. It corrects the AI-facing hitBody origin to
`origin + length1 * (cos(angle), sin(angle))`. It does not alter the game's actual
laser physics, collision rules, HP, or the upstream DLL file on disk.
The original exported vx/vy remain unchanged; Lua derives motion from the
corrected hitBody history. Failed sensor validation prevents that launch from
resuming. See `runtime/native-window.log` for `laser_sensor: install=ok` or
`laser_sensor: install=FAILED reason=...`.

Lua associates stable laser IDs across consecutive frames and predicts short-term
changes in hitBody origin, length, thickness and angle. Rotation uses a bounded
number of adaptive time intervals for conservative sweeps. Ordinary bullets keep the
fast continuous trajectory path. Marisa EX's non-hittable white-light emitter is
not treated as a solid projectile; zero-thickness lasers remain soft warnings.

Upgrade with the complete 2.0.5 package and retain the 2.0.4, 2.0.3, 2.0.2,
2.0.1, 2.0.0 and 0.1.9 ZIPs separately. Lua and native modules must match;
copying a single Lua file is insufficient. The core player sensor apiVersion 1
is retained with the read-only followupApiVersion 1 extension.
The default 600-second callback budget, input isolation, 1P practice options,
fail-closed sensor checks and window behavior are preserved.

## Preserved poison and state sensing (introduced in 0.1.9)

The native module reads effective poisoned movement speed, temporary protection
and recharge-related state without changing those game values. Lua treats
Medicine poison as nonlethal slowing terrain, predicts travel using effective
speed, and considers danger after temporary protection expires. This sensing
does not alter 2P HP, grant invincibility or remove poison.

The native/Lua snapshot must be valid and use apiVersion 1. A missing or invalid
snapshot releases all AI input and prints an error instead of silently falling
back to poison-blind movement. Recognized state-3 protection uses a conservative
remaining duration of max(floor(raw frames) - 1, 0) for avoidance; unknown states do not
grant assumed protection. Poison/protection handling adds no user configuration.

The user confirmed the 0.1.9 poison test passed before 2.0 development began.
That feedback does not validate the new bloom strategy for every character.
Spatial chain ranges and recharge estimates in 2.0 are heuristics, not verified
engine formulas; they do not guarantee that every C2 funds another C2.
There is no dedicated low-frame-rate or time-stop strategy. Existing game
installations are not automatically replaced when this release is packaged.

## Upstream runtime

The original inject.dll and legacy ka_ai_duka.exe in `dist/TH09-AI/runtime`
are copied unmodified from the author's release `ver1.7`. The additional
th09ai-launcher.exe and window_support.dll are built from this project's
src/native. Source and upstream license are included for audit.

## Launcher and controls

`src/native` contains the x86 launcher, checked machine-code patches and native
window subclass. `src/launcher` contains the user-facing startup scripts.
The game ignores saved key maps in keyboard mode, so the native launcher
remaps its LEFT reader to WASD + J/K/L for selection while preserving 1P FULL.
The 2P runtime OR instruction becomes MOV in memory; physical input no longer
leaks into AI battles, including the configured time-limit stop latch. Logical shot is
still called Z in Lua. Original game and upstream DLL disk files are unchanged.

`launcher-settings.json` is the entry point for the top-level `seconds` field:
an integer from 0 through 86400, default 600; 0 means unlimited. It also controls
window size and optional 1P practice protection. Restart the AI launcher after
changing JSON settings. The launcher generates `ai/runtime-settings.lua` on each
start; do not edit that generated file by hand.

The default window is 960x720 with native edge/corner dragging and a 4:3 aspect
constraint. The DLL handles hit testing, cursor, sizing and limits on the game's
GUI thread. It detects startup HWND destruction and reattaches to replacement
windows without repeatedly resetting a user's chosen size. Internal resolution
remains 640x480. Use custom.exe for windowed mode. Native events are logged to
runtime/native-window.log.

`practice.player1_no_damage` and `practice.player1_invincible` both default to
false and affect only 1P. No-damage preserves normal hit reactions and leaves HP
completely unchanged on every hit, including at 1 HP. Invincible prevents the
hit reaction and HP loss while contact still breaks the Spell Point combo. If
both are enabled, invincible takes precedence. Do not inject thprac at the same
time. See src/native/README.md for build and diagnostic details.

## Performance and tests

The planner retains the 0.1.3 continuous swept intersection intervals and
conservative velocity-aware filtering. Candidate paths are clamped to the field;
poison entry, exit and lifetime changes can split them into additional
effective-speed segments, with adjacent equal-speed segments merged.
It scans all hazards, does not cap bullet lists, and prefers collision-free
paths before scoring soft preferences. Direction hysteresis reduces jitter.

Run `python tests/run_native_lua.py tests/mock_ai_test.lua` and
`python tests/run_native_lua.py tests/dodge_perf_test.lua` from this project.
The runner requires Lua 5.1 via lupa (local test dependency under work).
The benchmark compares against tests/fixtures/dodge_0_1_2.lua, with the exact
upstream hitTest shape convention implemented in the test. It measures the Lua
planner, not full game FPS or native memory-to-Lua export costs.

Optional ai_debug.csv includes decision milliseconds and work counters for
real battle diagnosis. In 0.1.8 it also includes laser_count, tracked_lasers,
dynamic_lasers, laser_sweep_tests and laser_history_resets; the player README
defines their scope. These counters distinguish available geometry history from
the amount of candidate-trajectory work, not the game's total frame time.
Version 0.1.9 adds sensor_valid, move_scale_x, move_scale_y, protection_frames,
can_charge, charge_block_frames, poison_clouds, movement_segments and player_state.
protection_frames preserves the recognized raw remaining protection for diagnosis;
avoidance conservatively restores danger one update earlier. The timeScale value
is sensed, but there is no dedicated low-frame-rate or time-stop strategy.
Windows launcher compatibility includes CMD CRLF,
PowerShell 5.1 UTF-8 BOM, and literal paths containing brackets and Chinese.

The 0.1.9 baseline includes user-confirmed poison testing as well as earlier
window and 1P practice feedback. Version 2.0.0 changes the attack policy and its
interaction with positioning, so those historical results are not bloom
acceptance. Run the current offline suites and package/rebuild checks for every
release; do not carry forward their historical pass status.

Completed 0.1.9 checks include 432 player-sensor selftest assertions, owned-window
and laser selftests, 6 real upstream x86 player-export relocation cases, 36 laser
machine-code cases, 256 single-key and 128 input-combination isolation cases,
65,536 set-key cases, 12 two-sided practice combinations, and 4 suspended-start
support combinations with both sensors installed successfully. These suspended
checks did not create a game window or send game input. Launcher regression
passed 497 assertions and path regression passed 65; JSON seconds through the
real launcher to Lua's 60-active-callback stop latch also passed.

Version 2.0.5 remains a bloom test release awaiting user acceptance. Offline regression and successful
source rebuilds cannot establish all-character live acceptance. Check fairy
formation preservation, selective spirit capture, C1 setup, C2 recharge and
the independent C2 deadline and resource-starved waiting in real battles; preserve video, ai/ai_debug.csv and
runtime/native-window.log for unexpected behavior. No new 2.0 test results are
claimed by this historical baseline section.

## 2.0 policy regression and diagnostics

Run the observer, policy and movement suites through `tests/run_native_lua.py`:
`tests/bloom_observer_test.lua`, `tests/bloom_policy_test.lua`, and
`tests/bloom_movement_test.lua`. Version 2.0.4 adds `tests/bloom_observer_timing_test.lua`
and `tests/bloom_timing_test.lua` for chain-window observations and bounded prepare/armed
state transitions. Version 2.0.5 adds `tests/bloom_followup_policy_test.lua`,
`tests/bloom_followup_observer_test.lua`, `tests/bloom_followup_integration_test.lua`
and `tests/bloom_protected_route_test.lua` for follow-up input/capture, partial C1
coverage, main-loop gates and protection-expiry endpoints. These developer regression suites are not included in the public
source whitelist. `tests/mock_ai_test.lua` covers their main-loop
integration with input faults and timing. Existing poison and laser regressions
still apply. The all-character policy cases cover the 16 exported enum entries,
not a claim of individually verified field geometry or live wins.

Version 2.0.5 has 104 CSV columns, retaining the prior 88 and adding:
`capture_preferred`, `capture_value`, `capture_chain_bullets`, `c1_model_valid`, `c1_model_limited`, `c1_chain_bullets`, `c1_hit_count`, `common_waves_valid`, `common_wave_count`, `can_press_z`, `c1_action_active`, `followup_confirmed`, `followup_z_requests`, `followup_protection`, `protected_route_checked`, `protected_route_collides`.

Capture and C1 fields are planning estimates; model_limited reports incomplete
coverage. Common-wave counts describe eligible active listed type-1 circles,
not every effect or a native clear count. can_press_z and can_charge are distinct
gates. followup_confirmed associates a release request with live changes;
followup_z_requests is a separate Z-request counter, never an extra confirmed C1.
followup_protection is floor(raw protection)-1, clamped at zero.

protected_route_checked must be true before interpreting the endpoint result;
false collides with checked=false does not certify safety. The module also
returns protected_route_safe, horizon and work counters outside this CSV schema.
Old release counters remain requests. Position yields, chain timing and recharge
estimates are not observed kills/returns. A -1 exit time means no reliable
estimate, not unlimited waiting. Phase changes, releases and preparation
cancellation add event rows alongside the configured logging interval.

Resource-planned C2 preparation locks the original chain's node IDs. A disappearing lead fairy
does not lose a surviving connected chain, but unrelated replacement resources
cannot silently justify the attack. If that chain disperses before C2 matures,
release below C1 cancels; an already charged C1 ends there. Under the retained timing rules, an already sampled C2 may briefly wait for a clearly better retained
chain within 200..299, subject to the bounds above. A lost chain, urgent leak,
deadline or predicted crossing into C3 ends that wait.
Deadline-driven C2 bypasses the chain resource recheck/cancellation; energy and
action gates still apply, and it retains overdue debt when blocked.
