# TH09-AI

TH09-AI is a local 2P AI package for Touhou Kaeidzuka / Phantasmagoria of
Flower View v1.50a. It uses the redistributable ka_ai_duka v1.7 runtime and a new
Lua decision layer under `src/ai`.

Author: 圣诞老人的驯鹿-xunlu. The Chinese player manual is
`dist/TH09-AI/README.md`. Version 0.1.9.2 adds movement-only poison avoidance:
soft poison exposure risk and a bounded escape target encourage leaving dense
poison while immediate collision avoidance takes priority. It retains the 0.1.9
read-only state sensor and 0.1.8 laser correction, without new native fields.
Run `build-public-package.ps1` for a release that
includes the project source and third-party notices.

## License scope

The root MIT license applies to this project's original AI, launcher, native
helper source, build scripts and documentation. It does not relicense ka_ai_duka,
Lua, Boost, TinyCC runtime code, THprac material or the original Touhou game.
Third-party notices and exact applicable texts are in
`dist/TH09-AI/licenses/THIRD_PARTY_NOTICES.txt`. In particular, ka_ai_duka's author
permits redistribution with its LICENSE.txt; that file's Lua MIT notice is not
a blanket MIT grant for all of ka_ai_duka. The TinyCC startup code linked into
our EXE/DLL has separate LGPL terms; the public package includes corresponding
TinyCC source plus our buildable source and relinking instructions.

## Project layout

- `src/ai`: editable AI source.
- `dist/TH09-AI`: ready-to-copy test package.
- `vendor/ka_ai_duka-ver1.7-source`: exact upstream v1.7 source snapshot.
- `vendor/ka_ai_duka-src`: newer upstream master snapshot used for comparison.
- `vendor/ka_ai_duka_1_7_20150712.zip`: upstream release archive.

The package is designed to be copied as a `TH09-AI` subfolder beside
`th09.exe`. The launcher searches upward from its own parent directory for the
nearest `th09.exe`, allowing additional ZIP extraction wrapper directories.
It regenerates ka_ai_duka's absolute-path INI from the current location on every
launch, so moving the game/package does not retain an old installation path.

## Behavior contract

- Match Mode, Human vs Human, AI controls 2P.
- 2P must use the game's Option Charge Type = Slow: hold Z to charge and
  Shift for slow movement. The reversed Charge mode is unsupported; detecting
  it releases AI input and requests Slow mode. This does not change 1P's
  preference or add a JSON setting.
- Local limited-horizon bullet avoidance; it is intentionally not globally
  optimal and can be surrounded by converging C3 attacks.
- Uniform random C1/C2/C3/C4 by default. While energy is insufficient, tap Z
  on alternating frames for normal shots without deliberately charging.
- No X input under any circumstances.
- Stop shooting at Spell Point 500,000; resume only after it reaches zero.
- Stop all AI input at the configured battle limit (600 seconds by default),
  remaining stopped until the next battle. Count AI battle callbacks / 60,
  not wall-clock time. A limit of 0 disables the timer. Pause-menu scheduling
  has not been separately verified and is controlled by the original game.
- Treat every zero-height laser record as a soft warning; add configurable
  virtual thickness only when the warning meets warning_laser_min_length.
- Prefer leaving dense poison when a locally safe direction is available;
  do not force constant movement or couple poison escape to a new C policy.

## Laser perception correction (0.1.8)

The upstream Laser::Update export omits the raw.length1 offset when positioning
hitBody and reports laser vx/vy as zero. The new laser_sensor.c/.h support checks
the original runtime function and vtable before installing an in-memory export
hook during suspended startup. It corrects the AI-facing hitBody origin to
`origin + length1 * (cos(angle), sin(angle))`. It does not alter the game's actual
laser physics, collision rules, HP, or the upstream DLL file on disk.
The original exported vx/vy remain unchanged; Lua derives motion from the
corrected hitBody history. Failed sensor validation prevents that launch from
resuming. See `runtime/native-window.log` for `laser_sensor: install=ok` or
`laser_sensor: install=FAILED reason=...`.

Lua associates stable laser IDs across consecutive frames and predicts short-term
changes in hitBody origin, length, thickness and angle. Rotation uses a bounded
number of adaptive time intervals for conservative sweeps. Ordinary bullets keep the
fast continuous trajectory path. Marisa EX's non-hittable white-light emitter is
not treated as a solid projectile; zero-thickness lasers remain soft warnings.

Upgrade with the complete 0.1.9.2 package. Keep the existing 0.1.9 and earlier
ZIPs as separate rollback copies; do not mix individual scripts or overwrite
an installed game automatically. Native sensing is unchanged from 0.1.9, but
the release scripts, settings and diagnostics should stay together.
Random charge selection, tap shooting while energy is insufficient,
500,000-point shooting lock, no-X input, the default 600-second callback budget,
input isolation, practice options and window behavior are unchanged.

## Poison sensing baseline (0.1.9)

The native module reads effective poisoned movement speed, temporary protection
and recharge-related state without changing those game values. Lua treats
Medicine poison as nonlethal slowing terrain, predicts travel using effective
speed, and considers danger after temporary protection expires. This sensing
does not alter 2P HP, grant invincibility or remove poison.

The native/Lua snapshot must be valid and use apiVersion 1. A missing or invalid
snapshot releases all AI input and prints an error instead of silently falling
back to poison-blind movement. Recognized state-3 protection uses a conservative
remaining duration of max(floor(raw frames) - 1, 0) for avoidance; unknown states do not
grant assumed protection. The native sensor interface remains version 1.

## Movement-only poison escape (0.1.9.2)

Two 0.1.9 poison-test recordings were received. The reported behavior includes
repeated stops and staying in the poisoned area after a bullet clear. This
motivates a movement objective beyond merely surviving the next local collision.
The new Lua policy adds soft poison risk and a bounded escape target: it prefers
less poisoned destinations while preserving the collision-first candidate order.
Poison remains nonlethal terrain, not a solid damage obstacle, and standing
still remains allowed when safer. This is not a trained policy or global planner.

`src/ai/poison_navigation.lua` probes 16 directions with at most 8 points each,
within 128 internal coordinate units. Target scoring accounts for peak/average
route risk, target risk, fading clouds and near-future activation. Its bounded
terrain time estimate is not actual arrival time under stacked poison, nor a
proof that the entire route is bullet-free. Setting `dodge.poison_navigation`
to `{ enabled = false }` restores the earlier movement preferences without
disabling poison-aware speed prediction or the collision-first safety layer.

Defaults are `enabled=true`, `risk_weight=80` (clamped 0..1000),
`progress_weight=6` (clamped 0..100), and `replan_frames=12` (clamped 1..60,
then rounded down). These are Lua movement settings, not JSON or C-policy options.

Fixed random C selection, the 500,000-point Z lock and no-X rule remain unchanged.
There is no poison-triggered C release, adaptive C level or energy planning in
this update; future C coordination requires a separate decision. C does not
remove poison or cancel its slowing effect. Dense overlap can still leave no
reachable safe path, so the new preference is not a survival guarantee.

0.1.9.2 real-battle acceptance is pending player testing. Retain a video,
ai/ai_debug.csv and runtime/native-window.log if behavior is wrong. Packaging
does not automatically replace an existing game installation.

## Upstream runtime

The original inject.dll and legacy ka_ai_duka.exe in `dist/TH09-AI/runtime`
are copied unmodified from the author's release `ver1.7`. The additional
th09ai-launcher.exe and window_support.dll are built from this project's
src/native. Source and upstream license are included for audit.

## Launcher and controls (0.1.9.2)

`src/native` contains the x86 launcher, checked machine-code patches and native
window subclass. `src/launcher` contains the user-facing startup scripts.
The game ignores saved key maps in keyboard mode, so the native launcher
remaps its LEFT reader to WASD + J/K/L for selection while preserving 1P FULL.
The 2P runtime OR instruction becomes MOV in memory; physical input no longer
leaks into AI battles, including the configured time-limit stop latch. Logical shot is
still called Z in Lua. Original game and upstream DLL disk files are unchanged.

`launcher-settings.json` is the entry point for the top-level `seconds` field:
an integer from 0 through 86400, default 600; 0 means unlimited. It also controls
window size and optional 1P practice protection. Restart the AI launcher after
changing JSON settings. The launcher generates `ai/runtime-settings.lua` on each
start; do not edit that generated file by hand.

The default window is 960x720 with native edge/corner dragging and a 4:3 aspect
constraint. The DLL handles hit testing, cursor, sizing and limits on the game's
GUI thread. It detects startup HWND destruction and reattaches to replacement
windows without repeatedly resetting a user's chosen size. Internal resolution
remains 640x480. Use custom.exe for windowed mode. Native events are logged to
runtime/native-window.log.

`practice.player1_no_damage` and `practice.player1_invincible` both default to
false and affect only 1P. No-damage preserves normal hit reactions and leaves HP
completely unchanged on every hit, including at 1 HP. Invincible prevents the
hit reaction and HP loss while contact still breaks the Spell Point combo. If
both are enabled, invincible takes precedence. Do not inject thprac at the same
time. See src/native/README.md for build and diagnostic details.

## Performance and tests

The planner retains the 0.1.3 continuous swept intersection intervals and
conservative velocity-aware filtering. Candidate paths are clamped to the field;
poison entry, exit and lifetime changes can split them into additional
effective-speed segments, with adjacent equal-speed segments merged.
It scans all hazards, does not cap bullet lists, and prefers collision-free
paths before scoring soft preferences. Direction hysteresis reduces jitter.

Run `python tests/run_native_lua.py tests/mock_ai_test.lua` and
`python tests/run_native_lua.py tests/dodge_perf_test.lua` from this project.
The runner requires Lua 5.1 via lupa (local test dependency under work).
The benchmark compares against tests/fixtures/dodge_0_1_2.lua, with the exact
upstream hitTest shape convention implemented in the test. It measures the Lua
planner, not full game FPS or native memory-to-Lua export costs.

Optional ai_debug.csv includes decision milliseconds and work counters for
real battle diagnosis. In 0.1.8 it also includes laser_count, tracked_lasers,
dynamic_lasers, laser_sweep_tests and laser_history_resets; the player README
defines their scope. These counters distinguish available geometry history from
the amount of candidate-trajectory work, not the game's total frame time.
Version 0.1.9 adds sensor_valid, move_scale_x, move_scale_y, protection_frames,
can_charge, charge_block_frames, poison_clouds, movement_segments and player_state.
protection_frames preserves the recognized raw remaining protection for diagnosis;
avoidance conservatively restores danger one update earlier. The timeScale value
is sensed, but there is no dedicated low-frame-rate or time-stop strategy.
Windows launcher compatibility includes CMD CRLF,
PowerShell 5.1 UTF-8 BOM, and literal paths containing brackets and Chinese.

0.1.9.2 adds eight Lua diagnostics, for 42 CSV columns in total:
poison_nav_active (any candidate has nonzero navigation cost), poison_level
(current active overlap), poison_risk (current lifetime/activation-weighted
risk), poison_cost (selected candidate's cost, possibly negative progress reward),
poison_target_x/y (zero without a target), poison_probe_count (at most 128 new
ray endpoints), and poison_nav_samples (risk evaluations, not cloud count).
Each risk evaluation scans relevant clouds; the current bound is 172 calls on
replanning frames or 36 when reusing a target. None of these counters is full
game-frame time, and a nonzero poison_nav_active does not require actual motion.

Prior releases passed launcher, Lua, machine-code and owned-window regressions;
the user confirmed window dragging and invincibility, with no-damage logs showing
two protected hits at HP 10. Those results do not constitute real-battle
acceptance for 0.1.9.2 movement-only poison escape.

Completed 0.1.9 checks include 432 player-sensor selftest assertions, owned-window
and laser selftests, 6 real upstream x86 player-export relocation cases, 36 laser
machine-code cases, 256 single-key and 128 input-combination isolation cases,
65,536 set-key cases, 12 two-sided practice combinations, and 4 suspended-start
support combinations with both sensors installed successfully. These suspended
checks did not create a game window or send game input. Launcher regression
passed 497 assertions and path regression passed 65; JSON seconds through the
real launcher to Lua's 60-active-callback stop latch also passed.

Current 0.1.9.2 verification repeated and passed the native/ABI/input/practice/
suspended-start/launcher/path/timer checks listed above. It also passed 13
navigation behavior groups, 11 navigation benchmark scenarios, ordinary-bullet,
laser and poisoned-speed regressions, the three prior performance suites, mock
AI tests, 42-column CSV regression and 1,440 charge-policy parity states against
0.1.9. The parity check preserves Z decisions and RNG progression, alongside
no-X, Spell Point lock and operation-limit checks. Public ZIP and source-rebuild
results are recorded separately in this release's delivery test report.

Navigation benchmark coverage includes 256 clouds with 2,000 bullets and checks
the 128-probe/172-sample bounds. These synthetic Lua timings exclude the game
and native export cost; extreme cases can exceed 16.67 ms, so they are not a
60-FPS guarantee. In controlled escape tests, one-layer and three-layer exits
took 41 and 250 updates; five layers moved only 4.9152 internal units in 120
updates without escaping. These are scenario observations, not universal rates.
The two 0.1.9 recordings concern the old policy; 0.1.9.2 still requires new player
testing with Medicine. Automated tests, suspended startup and live play remain
distinct.
